DROP INDEX "#__user_keys_series_2";
DROP INDEX "#__user_keys_series_3";
