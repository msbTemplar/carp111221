ALTER TABLE `#__updates` ADD COLUMN `infourl` text NOT NULL AFTER `detailsurl`;
